<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap.css">
<?php
include 'connect.php';
//mysql_select_db($database); //connect to database
$dtbarang = mysqli_query($conn, "select * from barang");

	session_start();
	//unset($_SESSION['cart']);
	//session_destroy();
	//unset($_SESSION['cart']);
	
	//jika button diklik
	if (isset($_POST['add'])) {
		if (isset($_SESSION['cart'])) {
			//mengambil idbarang dari array_barang dan menyimpannya ke array_id_barang
			$array_id_barang = array_column($_SESSION['cart'], 'idbarang');
			//memeriksa apakah barang sudah ada berdasarkan idbarang
			if (!in_array($_GET['idbarang'], $array_id_barang)) {
				$count = count($_SESSION['cart']);
				$array_barang = array(
					'idbarang' => $_GET['idbarang'],
					'quantity' => $_POST['quantity'],
					'harga' => $_GET['harga']
				);
				$_SESSION['cart'][$count] = $array_barang;
			}
			else {
				//mengambil index dari barang dengan id = idbarang dari array id barang
				$index = array_search($_GET['idbarang'], $array_id_barang);
				//echo "index = '$index'";
				if($_POST['quantity'] <= 0) {
					echo '<script>alert("Quantity tidak valid")</script>';
				}
				else {
					$_SESSION['cart'][$index]['quantity'] += $_POST['quantity'];
				}
			}
		}
		else {
			$array_barang = array(
				'idbarang' => $_GET['idbarang'],
				'quantity' => $_POST['quantity'],
				'harga' => $_GET['harga']
			);
			$_SESSION['cart'][0] = $array_barang;
		}
	}
	
	if (isset($_GET['action'])) {
		if ($_GET['action']=='delete') {
			echo 'delete';
			foreach ($_SESSION['cart'] as $keys => $data) {
				echo 'delete';
				if ($data['idbarang']==$_GET['idbarang']) {
					unset($_SESSION['cart'][$keys]);
					echo '<script>alert("Item Removed")</script>';
				}
			}
		}
	}
	
	if (isset($_POST['deleteall'])) {
		unset($_SESSION['cart']);
	}
?>
<?php
	if(isset($_SESSION['cart'])) {
?>
<h1>Cart</h1>
<form action="" method="post" style="float: right;">
	<input type="submit" name="deleteall" value="Delete All" class="btn btn-default" style="background-color: blue; color: white;"/>
</form>
<table width="100%" height="50px" class="table table-striped">
	<thead>
		<tr>
			<th>ID BARANG</th>
			<th>NAMA BARANG</th>
			<th>HARGA</th>
			<th>JUMLAH</th>
			<th>ACTION</th>
		</tr>
	</thead>
	<tbody>
		<?php
			foreach ($_SESSION["cart"] as $barang){
				$id = $barang['idbarang'];
				$dtcart = mysqli_query($conn, "select * from barang where idbarang = '$id'");
				$data=mysqli_fetch_assoc($dtcart);
		?>
		<tr>
			<td><?php echo $data['idbarang']; ?></td>
			<td><?php echo $data['namabarang']; ?></td>
			<td><?php echo $barang['harga']; ?></td>
			<td><?php echo $barang['quantity']; ?></td>
			<td><a href='index.php?page=home&action=delete&idbarang=<?php echo $data['idbarang'];?>'>Delete</a></td>
		</tr>
		<?php
			}
		?>
	</tbody>
</table>
<a class="btn btn-lg btn-primary" href="index.php?page=checkout" role="button">Checkout &raquo;</a>
<?php
	}
?>
<div class="container">    
  <div class="row">
  <?php while($data=mysqli_fetch_assoc($dtbarang)){ ?>
    <div class="col-sm-4">
      <div class="panel">
	  <form method="post" action="index.php?page=home&idbarang=<?php echo $data['idbarang']; ?>
	   &harga=<?php echo $data['harga']; ?>">
        <div class="panel-heading"><?php echo $data['namabarang']; ?></div>
        <div class="panel-body"><a href='index.php?page=detail&foto=<?php echo $data['foto'];?>
			&idbarang=<?php echo $data['idbarang'];?>&namabarang=<?php echo $data['namabarang'];?>
			&harga=<?php echo $data['harga'];?>
			&keterangan=<?php echo $data['keterangan'];?>'>
		<img src="Foto/<?php echo $data['foto'];?>" class="img-responsive" style="width:70%; height:70%" alt="Image"></a></div>
        <div class="panel-footer">Rp.<?php echo $data['harga']; ?></div>
		<input type="text" name="quantity" value="1" size="2" />
		<input type="submit" name="add" value="Add2Cart" class="btn btn-default" style="background-color: blue; color: white;"/>
      </form></div>
    </div>
	<?php
	}
	?>
  </div>
</div><br>
<form action="export_excel.php" method="post">
	<input type="submit" name="export_excel" value="Export to Excel"/>
</form>
<form action="generate_pdf.php" method="post">
	<input type="submit" name="pdf" value="Generate PDF"/>
</form>

