<?php
	include 'session_toko_online.php';
?>
<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap.css">
<style>
	.leftPanel, .content {
		height: 80%;
		margin: 0;
	}
	
	.wrapTable {
		width: 100%;
	}
	
	.header, .footer {
		text-align: center; 
		height: 20%;
		background-color: #1D3C4D;
		color: white;
		padding: 0;
	}
	
	.leftPanel {
		width: 20%; 
		float: left;
		background-color: #65A4C7;
	}
	
	.content {
		margin-left: 20%; 
		text-align: center; 
		overflow: auto;
	}
	
	ul {
		list-style-type: none;
		margin: 0;
		padding: 0;
		width: 200px;
		height: 100%;
		width: 100%;
	}

	ul li {
		margin-bottom: 10%;
		text-align: center;
		font-size: 150%;
	}
	
	li a {
		display: block;
		color: #000;
		padding: 8px 16px;
		text-decoration: none;
	}

	/* Change the link color on hover */
	li a:hover {
		background-color: #1D3C4D;
		color: white;
		text-decoration: none;
	}
	
	.logo {
		clear: none;
		position: relative;
		float: left;
		width: 20%;
	}
	
	.logo img {
		border-radius: 50%;
		width: 50%;
		height: 100%;
	}
</style>
<div class="wrapTable">
	<div class="header">
		<div class="logo">
			<img src="info_current.png" title="Logo" alt="Logo" />
		</div>
		<div class="text-header">
			
		</div>
	</div>
	<div class="leftPanel">
		<div class="menu">
			<ul>
				<li><a href='?page=input'>Input</a></li>
				<li><a href='?page=display'>Display</a></li>
				<li><a href='?page=logout'>Logout</a></li>
			</ul>
		</div>
	</div>
	<div class="content">
		<?php
			$current_page = 'template';
			// Change value if `page` is specified
			if(array_key_exists('page',$_GET)) {
				$current_page = $_GET['page'];
			}
			// Check page
			switch ($current_page) {
				case 'display':
					include 'display_restoran.php';
					break;
				case 'input':
					include 'insert_restoran.php';
					break;
				case 'logout':
					session_destroy();
					header("Location:restoran.php");
					break;
			}
		?>
	</div>
	<div class="footer">
		Footer
	</div>
</div>
</table>