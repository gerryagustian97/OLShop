<?php
$servername = "localhost";
$username = "id5914370_root";
$password = "root123";
$database="id5914370_dbtokoonline";

$conn = mysqli_connect($servername,$username,$password,$database); //connect to server and db
?>